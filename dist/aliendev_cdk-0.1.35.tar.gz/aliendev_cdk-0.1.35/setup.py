# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['aliendev_cdk',
 'aliendev_cdk.config',
 'aliendev_cdk.service',
 'aliendev_cdk.service.template.helper',
 'aliendev_cdk.service.template.lib']

package_data = \
{'': ['*'], 'aliendev_cdk.service': ['template/*']}

install_requires = \
['configparser>=5.3.0,<6.0.0',
 'pika>=1.3.1,<2.0.0',
 'pymongo>=4.3.3,<5.0.0',
 'typer>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['aliendev-cdk = aliendev_cdk.main:app']}

setup_kwargs = {
    'name': 'aliendev-cdk',
    'version': '0.1.35',
    'description': '',
    'long_description': "### CDK Module\nThe CDK (Cloud Development Kit) module is a critical component of the serverless API, allowing clients to manage the deployment and configuration of the infrastructure required for the API's operation. It provides a simple and intuitive way to define and configure the necessary resources, such as AWS Lambda functions, API Gateway, and IAM roles, that are needed to run the API effectively.\n\nBy leveraging the power of the CDK, clients can easily define and deploy their serverless API infrastructure using familiar programming languages like TypeScript or Python. The CDK abstracts the underlying cloud infrastructure, providing a more user-friendly way to manage and maintain the API's components.\n\nSome of the key features of the CDK module include:\n\n- Easy-to-use APIs for defining and deploying infrastructure resources\n- Built-in support for popular AWS services like Lambda, API Gateway, and IAM\n- Comprehensive documentation and examples to get started quickly\n- Automatic dependency management and resource tracking to simplify maintenance and updates\n  \nUsing the CDK module, clients can quickly and easily deploy their serverless API with confidence, knowing that the underlying infrastructure is well-defined and optimized for performance and scalability.\n\nTo get started with the CDK module, refer to the documentation and examples provided in the cdk directory of this repository. From there, you can explore the APIs and learn how to define and deploy your serverless API infrastructure with ease.\n\n#\n\n### How to install\n```pip install aliendev-cdk```\n\n#\n\n### Create your first time project\n\n- Create project base template ```aliendev-cdk init```\nand enter your project name\n- For Register aliendev account ```aliendev-cdk register```\n- Login into your account ```aliendev-cdk login```\n- Sign Out using ```aliendev-cdk logout```\n  \n### Deploy your project\n```aliendev-cdk deploy```",
    'author': 'Nasri Adzlani',
    'author_email': 'nasri@jkt1.ebdesk.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
