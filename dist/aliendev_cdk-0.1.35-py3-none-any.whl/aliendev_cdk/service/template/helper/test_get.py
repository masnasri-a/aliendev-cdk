def handler(event:dict):
	return event